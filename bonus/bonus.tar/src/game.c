/*
** game.c for  in /home/joubert/delivery/raytracer1/bonus
** 
** Made by Joubert Miguel
** Login   <miguel.joubert@epitech.eu>
** 
** Started on  Sun Mar 19 17:56:25 2017 Joubert Miguel
** Last update Sun Mar 19 21:54:15 2017 Joubert Miguel
*/

#include "../include/my.h"

static t_attributs      get_co_game_three(t_attributs att)
{
  att.color.g = 100;
  att.color.a = 255;
  att.color.r = 0;
  att.color.g = 0;
  att.eye_pos.x = -1000;
  att.eye_pos.y = -1000;
  att.eye_pos.z = 200;
  att.dist_to_plane = 200;
  att.screen_size.x = 850;
  att.screen_size.y = 650;
  att.screen_pos.x = 0;
  att.screen_pos.y = 0;
  att.light_vector.x = 1000;
  att.light_vector.y = 200;
  att.light_vector.z = 0;
  att.semiangle = 100;
  att.limit_top = -250;
  att.limit_bottom = -450;
  return (att);
}

static t_attributs      get_co_game_two(t_attributs att)
{
  att.color.g = 100;
  att.color.a = 255;
  att.color.r = 0;
  att.color.g = 0;
  att.eye_pos.x = -1000;
  att.eye_pos.y = 0;
  att.eye_pos.z = 200;
  att.dist_to_plane = 200;
  att.screen_size.x = 850;
  att.screen_size.y = 650;
  att.screen_pos.x = 0;
  att.screen_pos.y = 0;
  att.light_vector.x = 1000;
  att.light_vector.y = 200;
  att.light_vector.z = 0;
  att.semiangle = 100;
  att.limit_top = -250;
  att.limit_bottom = -450;
  return (att);
}

static t_attributs	get_co_game_one(t_attributs att)
{
  att.color.g = 100;
  att.color.a = 255;
  att.color.r = 0;
  att.color.g = 0;
  att.eye_pos.x = -1000;
  att.eye_pos.y = 0;
  att.eye_pos.z = 200;
  att.dist_to_plane = 200;
  att.screen_size.x = 850;
  att.screen_size.y = 650;
  att.screen_pos.x = 0;
  att.screen_pos.y = 0;
  att.light_vector.x = 1000;
  att.light_vector.y = 200;
  att.light_vector.z = 0;
  att.semiangle = 100;
  att.limit_top = -250;
  att.limit_bottom = -450;
  return (att);
}

t_cond			ret_conds(int jump, t_attributs *att, t_my_framebuffer *framebuffer, sfRenderWindow *window)
{
  static t_cond		cond;

  cond.sprite_pos.y = 0;
  cond.mario_pos.x = 70;
  if (cond.i == 0) {
    cond.mario_pos.y = SCREEN_HEIGHT - 90;
    cond.i++;
  }
  if (jump == 1)
    cond.mario_pos.y -= 50;
  else if (cond.mario_pos.y != SCREEN_HEIGHT - 90)
    cond.mario_pos.y += 5;
  if (cond.reset == 0) {
    cond.reset = 1;
    cond.sprite_pos.x = 400;
  }
  else if (cond.sprite_pos.x > -500 && cond.reset == 1)
    cond.sprite_pos.x -= 5;
  else if (cond.sprite_pos.x <= -500 && cond.reset == 1) {
    cond.reset = 0;
  }
  if (cond.draw == 0) {
    *att = get_co_game_one(*att);
    sfRenderWindow_clear(window, sfBlack);
    radius_loop_cylinder(*att, framebuffer);
    //*att = get_co_game_two(*att);
    //radius_loop_cylinder(*att, framebuffer);
    cond.draw++;
  }
  return (cond);
}

void                    drawing_pipe(sfRenderWindow *window, sfSprite *pipe1,
				     t_my_framebuffer *framebuffer, int jump)
{
  t_cond		cond;
  sfSprite              *spr_mario;
  sfTexture             *tx_pipe1;
  sfTexture             *mario;
  t_attributs           att;

  cond = ret_conds(jump, &att, framebuffer, window);
  mario = sfTexture_createFromFile("rsrcs/mario.jpg", NULL);
  tx_pipe1 = sfTexture_create(SCREEN_WIDTH, SCREEN_HEIGHT);
  spr_mario = sfSprite_create();
  sfSprite_setTexture(pipe1, tx_pipe1, sfTrue);
  sfSprite_setTexture(spr_mario, mario, sfTrue);
  sfTexture_updateFromPixels(tx_pipe1, framebuffer->pixels,
  			     SCREEN_WIDTH, SCREEN_HEIGHT, 0, 0);
  sfTexture_updateFromPixels(mario, framebuffer->pixels,
			     0, 0, 50, 50);
  skip_all_pixels(framebuffer, tx_pipe1);
  sfSprite_setPosition(spr_mario, cond.mario_pos);
  sfSprite_setPosition(pipe1, cond.sprite_pos);
  sfRenderWindow_clear(window, sfBlack);
  sfRenderWindow_drawSprite(window, pipe1, NULL);
  sfRenderWindow_drawSprite(window, spr_mario, NULL);
  sfRenderWindow_display(window);
}

int		hardgame(sfRenderWindow *window, sfSprite *sprite,
			 t_my_framebuffer *framebuffer, int jump)
{
  drawing_pipe(window, sprite, framebuffer, jump);
  return (0);
}
